package com.example.shoppintapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void calculate(String w, String p){
        double wage = Double.parseDouble(w);
        double price = Double.parseDouble(p);
        if(wage <= 0) {
            ((TextView) findViewById(R.id.textView2)).setText("Invalid wage value");
        }else if(price <= 0){
            ((TextView) findViewById(R.id.textView2)).setText("Invalid price value");
        }else{
            double hours = (double) (Math.round((price / wage) * 100.0) / 100.0);
            ((TextView) findViewById(R.id.textView2)).setText(String.valueOf(hours) + " hours");
        }
    }

    public void buttonClicked(View v){
        EditText wageView = (EditText) findViewById(R.id.wageView);
        EditText priceView = (EditText) findViewById(R.id.priceView);
        calculate(wageView.getText().toString(), priceView.getText().toString());
    }
}